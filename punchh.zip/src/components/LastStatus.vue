<template>
  <div>{{ currentStatus }}</div>
</template>
<script>
export default {
  name: "LastStatus",
  props: ["currentStatus"],
};
</script>
